# app.py
from flask import Flask, request, render_template, jsonify
import sqlite3, os, secrets, bcrypt
from sympy import nextprime
from datetime import datetime
from functools import wraps

APP_PORT = 5000
DB = "honeycrypt.db"
app = Flask(__name__)
app.secret_key = secrets.token_hex(24)


# -------------------- DB helpers --------------------
def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password_hash TEXT,
        p TEXT,
        g TEXT,
        h TEXT
    )''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS challenges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        r TEXT,
        k TEXT,
        p TEXT,
        g TEXT,
        honey INTEGER DEFAULT 0,
        issued_at TEXT
    )''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        ip TEXT,
        challenge_id INTEGER,
        response TEXT,
        success INTEGER,
        honey_triggered INTEGER,
        created_at TEXT
    )''')
    conn.commit()
    conn.close()


def query_fetch(q, params=()):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute(q, params)
    rows = cur.fetchall()
    conn.close()
    return rows


def query_insert(q, params=()):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute(q, params)
    lastid = cur.lastrowid
    conn.commit()
    conn.close()
    return lastid


# -------------------- Number-theory helpers --------------------
def generate_group(bits=256):
    rnd = secrets.randbits(bits) | 1
    p = nextprime(rnd)
    g = 2
    return int(p), int(g)


def create_keypair(p, g):
    x = secrets.randbelow(p - 2) + 1
    h = pow(g, x, p)
    return x, h


# -------------------- utilities --------------------
def admin_required(f):
    @wraps(f)
    def wrapped(*a, **kw):
        if request.args.get("admin") != "1":
            return "Admin access only (append ?admin=1)", 403
        return f(*a, **kw)
    return wrapped


# -------------------- routes --------------------
@app.route("/")
def index():
    return render_template("register.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """
    GET -> serve register page
    POST (JSON) -> return JSON with key (do not redirect)
    """
    if request.method == "POST":
        # Expect JSON from frontend
        data = request.get_json() or {}
        username = (data.get("username") or "").strip()
        password = (data.get("password") or "").strip()

        if not username or not password:
            return jsonify({"success": False, "message": "Username and password required"}), 400

        exists = query_fetch("SELECT 1 FROM users WHERE username = ?", (username,))
        if exists:
            return jsonify({"success": False, "message": "Username already exists"}), 409

        # Hash password (bcrypt)
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        # Number-theory keypair generation (server generates x and returns it to client; server stores only public h)
        p, g = generate_group(bits=256)
        x, h = create_keypair(p, g)

        query_insert("INSERT INTO users (username, password_hash, p, g, h) VALUES (?,?,?,?,?)",
                     (username, pw_hash, str(p), str(g), str(h)))

        key_json = {"username": username, "p": str(p), "g": str(g), "x": str(x)}
        return jsonify({"success": True, "message": "Registered", "key": key_json}), 200

    return render_template("register.html")


@app.route("/challenge", methods=["POST"])
def challenge():
    """
    Expects JSON: { username, password }
    Returns JSON challenge { challenge_id, r, p, g, honey }
    """
    data = request.get_json() or {}
    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    def make_honey(reason):
        p, g = generate_group(bits=256)
        k = secrets.randbelow(2**20) + 2
        r = pow(g, k, p)
        cid = query_insert("INSERT INTO challenges (username, r, k, p, g, honey, issued_at) VALUES (?,?,?,?,?,?,?)",
                           (username, str(r), str(k), str(p), str(g), 1, datetime.utcnow().isoformat()))
        return jsonify({"challenge_id": cid, "r": str(r), "p": str(p), "g": str(g), "honey": 1, "message": f"honey: {reason}"}), 200

    if not username:
        return make_honey("no username")

    user = query_fetch("SELECT password_hash, p, g, h FROM users WHERE username = ?", (username,))
    if not user:
        return make_honey("unknown user")

    stored_hash = user[0][0]
    if not bcrypt.checkpw(password.encode(), stored_hash.encode()):
        return make_honey("wrong password")

    # legitimate challenge
    p = int(user[0][1]); g = int(user[0][2])
    k = secrets.randbelow(2**20) + 2
    r = pow(g, k, p)
    cid = query_insert("INSERT INTO challenges (username, r, k, p, g, honey, issued_at) VALUES (?,?,?,?,?,?,?)",
                       (username, str(r), str(k), str(p), str(g), 0, datetime.utcnow().isoformat()))
    return jsonify({"challenge_id": cid, "r": str(r), "p": str(p), "g": str(g), "honey": 0, "message": "challenge issued"}), 200


@app.route("/verify", methods=["POST"])
def verify():
    """
    Expects JSON: { username, challenge_id, response }
    Returns JSON always. On success include {"redirect": "/cicada"} so client may redirect.
    """
    data = request.get_json() or {}
    username = data.get("username", "")
    try:
        challenge_id = int(data.get("challenge_id", 0))
    except Exception:
        return jsonify({"success": False, "message": "invalid challenge_id"}), 400

    response_val_raw = data.get("response", "")
    try:
        response_int = int(str(response_val_raw).strip())
    except Exception:
        return jsonify({"success": False, "message": "response must be integer string"}), 400

    ip = request.remote_addr

    ch = query_fetch("SELECT id, username, r, k, p, g, honey FROM challenges WHERE id = ?", (challenge_id,))
    if not ch:
        return jsonify({"success": False, "message": "challenge not found"}), 404

    ch = ch[0]
    k = int(ch[3])
    p = int(ch[4])
    honey = int(ch[6])

    success = 0
    honey_triggered = 0

    if honey:
        honey_triggered = 1
        success = 0
    else:
        user = query_fetch("SELECT h FROM users WHERE username = ?", (username,))
        if not user:
            success = 0
        else:
            h = int(user[0][0])
            expected = pow(h, k, p)
            if expected == response_int:
                success = 1

    query_insert("INSERT INTO attempts (username, ip, challenge_id, response, success, honey_triggered, created_at) VALUES (?,?,?,?,?,?,?)",
                 (username, ip, str(challenge_id), str(response_int), success, honey_triggered, datetime.utcnow().isoformat()))

    if success:
        # Return JSON that tells client to redirect to cicada
        return jsonify({"success": True, "honey_triggered": False, "message": "authenticated", "redirect": "/cicada"}), 200

    return jsonify({"success": False, "honey_triggered": bool(honey_triggered),
                    "message": ("honey triggered" if honey_triggered else "authentication failed")}), 200


@app.route("/login")
def login():
    return render_template("login.html")


@app.route("/dashboard")
@admin_required
def dashboard():
    attempts = query_fetch("SELECT id, username, ip, challenge_id, response, success, honey_triggered, created_at FROM attempts ORDER BY id DESC LIMIT 100")
    challenges = query_fetch("SELECT id, username, r, p, g, honey, issued_at FROM challenges ORDER BY id DESC LIMIT 100")
    return render_template("dashboard.html", attempts=attempts, challenges=challenges)


@app.route("/cicada")
def cicada():
    # A public 3D landing page — client redirects here after successful auth
    return render_template("cicada.html")


if __name__ == "__main__":
    if not os.path.exists(DB):
        init_db()
    app.run(host="0.0.0.0", port=APP_PORT, debug=True)

